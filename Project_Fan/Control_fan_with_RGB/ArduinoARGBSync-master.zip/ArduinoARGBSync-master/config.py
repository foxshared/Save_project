# config.py

# Enable Flask's debugging features. Should be False in production
DEBUG = True
PORT = 80